#pragma once
#include"Draw.h"
class Rank
{
public:
	void Showrank();
	Rank();
	~Rank();
};

