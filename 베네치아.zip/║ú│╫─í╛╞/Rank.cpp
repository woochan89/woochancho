#include "Rank.h"



Rank::Rank()
{
}

void Rank::Showrank()
{

}


Rank::~Rank()
{
}
