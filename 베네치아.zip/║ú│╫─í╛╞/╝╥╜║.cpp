#include"Play.h"

void main()
{
	Play Gamemanager;
}