#include "Table.h"
#define NULL 0

//���̺� �ʱ�ȭ
void TBLinit(Table *tbl, keyfunc func)
{
	for (int i = 0; i < ARRMAX; i++) {
		tbl->tblarr[i].status = EMPTY;
	}
	tbl->func = func;
}

//����
void TBLinsert(Table *tbl, Value v)
{
	int key = tbl->func(v->ssn);
	tbl->tblarr[key].value = v;
	tbl->tblarr[key].key = key;
	tbl->tblarr[key].status = INUSE;
}

//��ȸ
Value TBLresearch(Table *tbl, int ssn)
{
	if (tbl->tblarr[tbl->func(ssn)].status == INUSE)
		return tbl->tblarr[tbl->func(ssn)].value;
	else return NULL;
}

//����
Value TBLremove(Table *tbl, int ssn)
{
	if (tbl->tblarr[tbl->func(ssn)].status == INUSE)
	{
		tbl->tblarr[tbl->func(ssn)].status = DELETED;
		return tbl->tblarr[tbl->func(ssn)].value;
	}
	else return NULL;
}
