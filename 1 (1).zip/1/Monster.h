#pragma once
class Monster
{
public:
	Monster();
	~Monster();
};

