#include "Battle.h"



Battle::Battle()
{
}

void Battle::BattleInterface(int Floor)
{
	system("cls");
	DrawManager.DrawBox();

}

Battle::~Battle()
{
}
