#include"Village.h"

//struct Monster
//{
//	int Hp=10;
//	int Mp=2;
//	int Atk=2;
//	int Def = 1;
//	int X;
//	bool team;
//};

//struct Character
//{
//	string Head;
//	string Body =  "������";
//	string Leg =  "  ��  ";
//	string Foot =  " �� ��";
//};


void main()
{
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);
	//_crtBreakAlloc = 275;
	//Alive.Head = "(��.��)";
	//Dead.Head = "(��.��)";
	//for (int i = 0; i < 6; i++)
	//{
	//	M[i].X = i;
	//	if (i < 3)
	//		M[i].team = 0;
	//	else
	//		M[i].team = 1;
	//}
	//for (int i = 0; i < 5; i++)
	//{
	//	gotoxy(i * 8, 0);
	//	cout << Alive;
	//}
	Village GameManager;
}