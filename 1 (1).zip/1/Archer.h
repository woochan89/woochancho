#pragma once
#include"Character.h"
class Archer:public Character
{
public:
	Archer();
	void InputData(int Class=NULL);
	~Archer();
};

