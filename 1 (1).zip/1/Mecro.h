#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
#include<time.h>
#include<conio.h>
using namespace std;
#define WIDTH 40
#define HEIGHT 40

