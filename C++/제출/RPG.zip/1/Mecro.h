#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
#include<time.h>
#include<conio.h>
#include<fstream>
using namespace std;
#define WIDTH 60
#define HEIGHT 40

