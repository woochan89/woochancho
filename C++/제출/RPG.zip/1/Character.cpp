#include "Character.h"



Character::Character()
{
}

int Character::RandClass()
{
	int Class;

	Class = rand() % 100;
	if (Class < 40)
		Class = 5;
	else if (Class < 70)
		Class = 4;
	else if (Class < 85)
		Class = 3;
	else if (Class < 95)
		Class = 2;
	else
		Class = 1;

	return Class;
}

void Character::ShowStat(int X, int Y)
{
	DrawManager.gotoxy(X, Y);
	cout << "��������������������������������������������������" ;
	DrawManager.gotoxy(X, Y+1);
	cout << "  �̸� : " << m_sName << "\t���� : " << m_iLv << "\t����ġ " << m_iCurExp << "/" << m_iMaxExp;
	DrawManager.gotoxy(X, Y+2);
	cout << "  ATK : " << m_iAtk << "      \tDEF : " << m_iDef <<"    \t��� "<<m_iClass;
	DrawManager.gotoxy(X, Y+3);
	cout << "  ��Ÿ� : " << m_iRange << "\tHP" << m_iCurHp <<"/"<<m_iMaxHp;
	DrawManager.gotoxy(X, Y+4);
	cout << "��������������������������������������������������" << endl;
}

void Character::ShowBattleStat(int Check,int Num)
{
	int x, y,add;
	y = HEIGHT * 0.5;
	if (Check == PLAYER)
	{
		x = 45;
		add = -16;
	}
	else
	{
		x = 65;
		add = 16;
	}
	DrawManager.gotoxy(x+(Num*add), y+1);
	cout << m_sName << " LV:" << m_iLv;
	DrawManager.gotoxy(x + (Num*add), y+2);
	cout << "ATK:" << m_iAtk << "    DEF:" << m_iDef;
	DrawManager.gotoxy(x + (Num*add), y + 3);
	cout << "��Ÿ� : "<<m_iRange<<"  ";
	DrawManager.gotoxy(x + (Num*add), y + 4);
	cout << "HP:" << m_iCurHp << "/" << m_iMaxHp<<"   ";
	DrawCharacter(x + (Num * add) +1,y-7);
}

void Character::DealToEnemy(int DmgToEnemy[],Character *EnemyList[])
{
	int Target;

	if (m_iCurHp == 0)
		return;

	if (m_iRange == 1)
		Target = P1;
	else if (m_iRange == 2)
		Target = P2;
	else
		Target = P3;

	if (EnemyList[Target]->m_iCurHp == 0)
	{
		if (Target == P1)
		{
			if(EnemyList[P2]->m_iCurHp!=0)
				DmgToEnemy[P2] += m_iAtk;
			else
				DmgToEnemy[P3] += m_iAtk;
		}
		else if (Target == P2)
		{
			if (EnemyList[P1]->m_iCurHp != 0)
				DmgToEnemy[P1] += m_iAtk;
			else
				DmgToEnemy[P3] += m_iAtk;

		}
		else if (Target == P3)
		{
			if (EnemyList[P1]->m_iCurHp != 0)
				DmgToEnemy[P1] += m_iAtk;
			else
				DmgToEnemy[P2] += m_iAtk;
		}
		return;
	}

	DmgToEnemy[Target] += m_iAtk;
}

void Character::GetDmg(int Dmg[],int Target)
{
	if (Dmg[Target] == 0)
		return;
	int FinalDmg = Dmg[Target] - m_iDef;
	if (FinalDmg <= 0)
		FinalDmg = 1;
	m_iCurHp -= FinalDmg;
	if (m_iCurHp < 0)
		m_iCurHp = 0;
}

bool Character::WinCheck()
{
	if (m_iCurHp == 0)
		return true;
	return false;
}

void Character::Recovery(int Percent)
{
	if (Percent <= 0)
		return;
	m_iCurHp += (m_iMaxHp*Percent*0.01);
	if (m_iCurHp > m_iMaxHp)
		m_iCurHp = m_iMaxHp;
}

void Character::DrawCharacter(int x, int y)
{
	//���߰�
	DrawManager.gotoxy(x, y);
	if (m_iCurHp == 0)
		cout << "(��.��)";
	else
		cout << "(��.��)";
	DrawManager.gotoxy(x, y+1);
	cout<<"������";
	DrawManager.gotoxy(x, y+2);
	cout << "  ��  ";
	DrawManager.gotoxy(x, y+3);
	cout << " �� ��";
	//������
}

void Character::GetData(Character *Player)
{
	m_sName = Player->m_sName;
	m_iAtk = Player->m_iAtk;
	m_iDef = Player->m_iDef;
	m_iLv = Player->m_iLv;
	m_iClass = Player->m_iClass;
	m_iRange = Player->m_iRange;
	m_iMaxHp = Player->m_iMaxHp;
	m_iCurHp = m_iMaxHp;
	m_iMaxExp = Player->m_iMaxExp;
	m_iCurExp = Player->m_iCurExp;
}

void Character::SaveData()//����
{
	ofstream save;
	save.open("Save.txt",ios::app);
	save << m_sName << " " << m_iClass << " " << m_iLv << " " << m_iAtk << " " 
		<< m_iDef << " " << m_iRange << " " << m_iMaxHp << " " << m_iCurHp << " " << m_iMaxExp << " " << m_iCurExp << endl;
	save.close();
}

void Character::LoadData(int Num)
{
	ifstream load;
	string tmp;
	load.open("Save.txt");
	for (int i = 0; i < (Num*10)+2; i++)
		load >> tmp;
	load >> m_sName;
	load >> m_iClass;
	load >> m_iLv;
	load >> m_iAtk;
	load >> m_iDef;
	load >> m_iRange;
	load >> m_iMaxHp;
	load >> m_iCurHp;
	load >> m_iMaxExp;
	load >> m_iCurExp;
	load.close();

}

Character::~Character()
{
}