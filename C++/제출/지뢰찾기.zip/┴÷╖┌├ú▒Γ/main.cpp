//#include"Game.h"
//
//void main()
//{
//	Game Gamemanager;
//}