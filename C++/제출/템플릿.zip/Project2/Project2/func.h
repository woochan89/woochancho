#pragma once
#include<iostream>
using namespace std;

template <typename T>
class func
{
public:
	void Quiz1(T num);
	void Quiz2(T num1, T num2);
	void Quiz3(T num1, T num2, T Num3);
	func();
	~func();
};

