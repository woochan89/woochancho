#pragma once
#include"Draw.h"
#include"mecro.h"

class Rank
{
private:
	Draw Drawmanager;
public:
	void Showrank();
	Rank();
	~Rank();
};

